--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.13 (Debian 13.13-1.pgdg120+1)
-- Dumped by pg_dump version 13.13 (Debian 13.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE directus;
--
-- Name: directus; Type: DATABASE; Schema: -; Owner: directus
--

CREATE DATABASE directus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE directus OWNER TO directus;

\connect directus

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accordion; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.accordion (
    id integer NOT NULL,
    accordion integer
);


ALTER TABLE public.accordion OWNER TO directus;

--
-- Name: accordion_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.accordion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accordion_id_seq OWNER TO directus;

--
-- Name: accordion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.accordion_id_seq OWNED BY public.accordion.id;


--
-- Name: blockAccordion; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockAccordion" (
    id integer NOT NULL,
    "manualSort" integer,
    "Internal_Title" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockAccordion" OWNER TO directus;

--
-- Name: blockAccordionItem; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockAccordionItem" (
    id integer NOT NULL,
    accordion integer,
    "manualSort" integer,
    icon character varying(255) DEFAULT NULL::character varying,
    title character varying(255) DEFAULT NULL::character varying,
    content text,
    "Internal_Titel" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockAccordionItem" OWNER TO directus;

--
-- Name: blockAccordionItem_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockAccordionItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockAccordionItem_id_seq" OWNER TO directus;

--
-- Name: blockAccordionItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockAccordionItem_id_seq" OWNED BY public."blockAccordionItem".id;


--
-- Name: blockAccordion_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockAccordion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockAccordion_id_seq" OWNER TO directus;

--
-- Name: blockAccordion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockAccordion_id_seq" OWNED BY public."blockAccordion".id;


--
-- Name: blockCard; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockCard" (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    page integer,
    "manualSort" integer,
    image uuid,
    "Internal_Titel" character varying(255) DEFAULT NULL::character varying,
    content character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockCard" OWNER TO directus;

--
-- Name: blockCardGroup; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockCardGroup" (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    "manualSort" integer,
    "internalTitle" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockCardGroup" OWNER TO directus;

--
-- Name: blockCardGroup_blockCard; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockCardGroup_blockCard" (
    id integer NOT NULL,
    "blockCardGroup_id" integer,
    card integer,
    "manualSort" integer
);


ALTER TABLE public."blockCardGroup_blockCard" OWNER TO directus;

--
-- Name: blockCardGroup_blockCard_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockCardGroup_blockCard_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockCardGroup_blockCard_id_seq" OWNER TO directus;

--
-- Name: blockCardGroup_blockCard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockCardGroup_blockCard_id_seq" OWNED BY public."blockCardGroup_blockCard".id;


--
-- Name: blockCardGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockCardGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockCardGroup_id_seq" OWNER TO directus;

--
-- Name: blockCardGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockCardGroup_id_seq" OWNED BY public."blockCardGroup".id;


--
-- Name: blockCard_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockCard_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockCard_id_seq" OWNER TO directus;

--
-- Name: blockCard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockCard_id_seq" OWNED BY public."blockCard".id;


--
-- Name: blockLink; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockLink" (
    id integer NOT NULL,
    name character varying(255) DEFAULT NULL::character varying,
    url character varying(255) DEFAULT NULL::character varying,
    "manualSort" integer,
    "linkGroupId" integer,
    page integer,
    "footerId" integer,
    "contactForm" boolean DEFAULT false,
    "Internal_Titel" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockLink" OWNER TO directus;

--
-- Name: blockLinkGroup; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockLinkGroup" (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    "manualSort" integer
);


ALTER TABLE public."blockLinkGroup" OWNER TO directus;

--
-- Name: blockLinkGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockLinkGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockLinkGroup_id_seq" OWNER TO directus;

--
-- Name: blockLinkGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockLinkGroup_id_seq" OWNED BY public."blockLinkGroup".id;


--
-- Name: blockLink_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockLink_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockLink_id_seq" OWNER TO directus;

--
-- Name: blockLink_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockLink_id_seq" OWNED BY public."blockLink".id;


--
-- Name: blockPopup; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockPopup" (
    id integer NOT NULL,
    title character varying(255) DEFAULT NULL::character varying,
    icon character varying(255) DEFAULT NULL::character varying,
    content text
);


ALTER TABLE public."blockPopup" OWNER TO directus;

--
-- Name: blockPopup_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockPopup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockPopup_id_seq" OWNER TO directus;

--
-- Name: blockPopup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockPopup_id_seq" OWNED BY public."blockPopup".id;


--
-- Name: blockSmallText; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."blockSmallText" (
    id integer NOT NULL,
    content text,
    "Internal_Title" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."blockSmallText" OWNER TO directus;

--
-- Name: blockSmallText_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."blockSmallText_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."blockSmallText_id_seq" OWNER TO directus;

--
-- Name: blockSmallText_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."blockSmallText_id_seq" OWNED BY public."blockSmallText".id;


--
-- Name: cardGroup; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."cardGroup" (
    id integer NOT NULL,
    "cardGroup" integer
);


ALTER TABLE public."cardGroup" OWNER TO directus;

--
-- Name: cardGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."cardGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."cardGroup_id_seq" OWNER TO directus;

--
-- Name: cardGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."cardGroup_id_seq" OWNED BY public."cardGroup".id;


--
-- Name: directus_activity; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_activity (
    id integer NOT NULL,
    action character varying(45) NOT NULL,
    "user" uuid,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip character varying(50),
    user_agent text,
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    comment text,
    origin character varying(255)
);


ALTER TABLE public.directus_activity OWNER TO directus;

--
-- Name: directus_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_activity_id_seq OWNER TO directus;

--
-- Name: directus_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_activity_id_seq OWNED BY public.directus_activity.id;


--
-- Name: directus_collections; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_collections (
    collection character varying(64) NOT NULL,
    icon character varying(30),
    note text,
    display_template character varying(255),
    hidden boolean DEFAULT false NOT NULL,
    singleton boolean DEFAULT false NOT NULL,
    translations json,
    archive_field character varying(64),
    archive_app_filter boolean DEFAULT true NOT NULL,
    archive_value character varying(255),
    unarchive_value character varying(255),
    sort_field character varying(64),
    accountability character varying(255) DEFAULT 'all'::character varying,
    color character varying(255),
    item_duplication_fields json,
    sort integer,
    "group" character varying(64),
    collapse character varying(255) DEFAULT 'open'::character varying NOT NULL,
    preview_url character varying(255),
    versioning boolean DEFAULT false NOT NULL
);


ALTER TABLE public.directus_collections OWNER TO directus;

--
-- Name: directus_dashboards; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_dashboards (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30) DEFAULT 'dashboard'::character varying NOT NULL,
    note text,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid,
    color character varying(255)
);


ALTER TABLE public.directus_dashboards OWNER TO directus;

--
-- Name: directus_extensions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_extensions (
    enabled boolean DEFAULT true NOT NULL,
    id uuid NOT NULL,
    folder character varying(255) NOT NULL,
    source character varying(255) NOT NULL,
    bundle uuid
);


ALTER TABLE public.directus_extensions OWNER TO directus;

--
-- Name: directus_fields; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_fields (
    id integer NOT NULL,
    collection character varying(64) NOT NULL,
    field character varying(64) NOT NULL,
    special character varying(64),
    interface character varying(64),
    options json,
    display character varying(64),
    display_options json,
    readonly boolean DEFAULT false NOT NULL,
    hidden boolean DEFAULT false NOT NULL,
    sort integer,
    width character varying(30) DEFAULT 'full'::character varying,
    translations json,
    note text,
    conditions json,
    required boolean DEFAULT false,
    "group" character varying(64),
    validation json,
    validation_message text
);


ALTER TABLE public.directus_fields OWNER TO directus;

--
-- Name: directus_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_fields_id_seq OWNER TO directus;

--
-- Name: directus_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_fields_id_seq OWNED BY public.directus_fields.id;


--
-- Name: directus_files; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_files (
    id uuid NOT NULL,
    storage character varying(255) NOT NULL,
    filename_disk character varying(255),
    filename_download character varying(255) NOT NULL,
    title character varying(255),
    type character varying(255),
    folder uuid,
    uploaded_by uuid,
    uploaded_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by uuid,
    modified_on timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    charset character varying(50),
    filesize bigint,
    width integer,
    height integer,
    duration integer,
    embed character varying(200),
    description text,
    location text,
    tags text,
    metadata json,
    focal_point_x integer,
    focal_point_y integer
);


ALTER TABLE public.directus_files OWNER TO directus;

--
-- Name: directus_flows; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_flows (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    icon character varying(30),
    color character varying(255),
    description text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    trigger character varying(255),
    accountability character varying(255) DEFAULT 'all'::character varying,
    options json,
    operation uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_flows OWNER TO directus;

--
-- Name: directus_folders; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_folders (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    parent uuid
);


ALTER TABLE public.directus_folders OWNER TO directus;

--
-- Name: directus_migrations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_migrations (
    version character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.directus_migrations OWNER TO directus;

--
-- Name: directus_notifications; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_notifications (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(255) DEFAULT 'inbox'::character varying,
    recipient uuid NOT NULL,
    sender uuid,
    subject character varying(255) NOT NULL,
    message text,
    collection character varying(64),
    item character varying(255)
);


ALTER TABLE public.directus_notifications OWNER TO directus;

--
-- Name: directus_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_notifications_id_seq OWNER TO directus;

--
-- Name: directus_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_notifications_id_seq OWNED BY public.directus_notifications.id;


--
-- Name: directus_operations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_operations (
    id uuid NOT NULL,
    name character varying(255),
    key character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    options json,
    resolve uuid,
    reject uuid,
    flow uuid NOT NULL,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_operations OWNER TO directus;

--
-- Name: directus_panels; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_panels (
    id uuid NOT NULL,
    dashboard uuid NOT NULL,
    name character varying(255),
    icon character varying(30) DEFAULT NULL::character varying,
    color character varying(10),
    show_header boolean DEFAULT false NOT NULL,
    note text,
    type character varying(255) NOT NULL,
    position_x integer NOT NULL,
    position_y integer NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    options json,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid
);


ALTER TABLE public.directus_panels OWNER TO directus;

--
-- Name: directus_permissions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_permissions (
    id integer NOT NULL,
    role uuid,
    collection character varying(64) NOT NULL,
    action character varying(10) NOT NULL,
    permissions json,
    validation json,
    presets json,
    fields text
);


ALTER TABLE public.directus_permissions OWNER TO directus;

--
-- Name: directus_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_permissions_id_seq OWNER TO directus;

--
-- Name: directus_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_permissions_id_seq OWNED BY public.directus_permissions.id;


--
-- Name: directus_presets; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_presets (
    id integer NOT NULL,
    bookmark character varying(255),
    "user" uuid,
    role uuid,
    collection character varying(64),
    search character varying(100),
    layout character varying(100) DEFAULT 'tabular'::character varying,
    layout_query json,
    layout_options json,
    refresh_interval integer,
    filter json,
    icon character varying(30) DEFAULT 'bookmark'::character varying,
    color character varying(255)
);


ALTER TABLE public.directus_presets OWNER TO directus;

--
-- Name: directus_presets_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_presets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_presets_id_seq OWNER TO directus;

--
-- Name: directus_presets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_presets_id_seq OWNED BY public.directus_presets.id;


--
-- Name: directus_relations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_relations (
    id integer NOT NULL,
    many_collection character varying(64) NOT NULL,
    many_field character varying(64) NOT NULL,
    one_collection character varying(64),
    one_field character varying(64),
    one_collection_field character varying(64),
    one_allowed_collections text,
    junction_field character varying(64),
    sort_field character varying(64),
    one_deselect_action character varying(255) DEFAULT 'nullify'::character varying NOT NULL
);


ALTER TABLE public.directus_relations OWNER TO directus;

--
-- Name: directus_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_relations_id_seq OWNER TO directus;

--
-- Name: directus_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_relations_id_seq OWNED BY public.directus_relations.id;


--
-- Name: directus_revisions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_revisions (
    id integer NOT NULL,
    activity integer NOT NULL,
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    data json,
    delta json,
    parent integer,
    version uuid
);


ALTER TABLE public.directus_revisions OWNER TO directus;

--
-- Name: directus_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_revisions_id_seq OWNER TO directus;

--
-- Name: directus_revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_revisions_id_seq OWNED BY public.directus_revisions.id;


--
-- Name: directus_roles; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(30) DEFAULT 'supervised_user_circle'::character varying NOT NULL,
    description text,
    ip_access text,
    enforce_tfa boolean DEFAULT false NOT NULL,
    admin_access boolean DEFAULT false NOT NULL,
    app_access boolean DEFAULT true NOT NULL
);


ALTER TABLE public.directus_roles OWNER TO directus;

--
-- Name: directus_sessions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_sessions (
    token character varying(64) NOT NULL,
    "user" uuid,
    expires timestamp with time zone NOT NULL,
    ip character varying(255),
    user_agent text,
    share uuid,
    origin character varying(255)
);


ALTER TABLE public.directus_sessions OWNER TO directus;

--
-- Name: directus_settings; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_settings (
    id integer NOT NULL,
    project_name character varying(100) DEFAULT 'Directus'::character varying NOT NULL,
    project_url character varying(255),
    project_color character varying(255) DEFAULT '#6644FF'::character varying NOT NULL,
    project_logo uuid,
    public_foreground uuid,
    public_background uuid,
    public_note text,
    auth_login_attempts integer DEFAULT 25,
    auth_password_policy character varying(100),
    storage_asset_transform character varying(7) DEFAULT 'all'::character varying,
    storage_asset_presets json,
    custom_css text,
    storage_default_folder uuid,
    basemaps json,
    mapbox_key character varying(255),
    module_bar json,
    project_descriptor character varying(100),
    default_language character varying(255) DEFAULT 'en-US'::character varying NOT NULL,
    custom_aspect_ratios json,
    public_favicon uuid,
    default_appearance character varying(255) DEFAULT 'auto'::character varying NOT NULL,
    default_theme_light character varying(255),
    theme_light_overrides json,
    default_theme_dark character varying(255),
    theme_dark_overrides json,
    report_error_url character varying(255),
    report_bug_url character varying(255),
    report_feature_url character varying(255)
);


ALTER TABLE public.directus_settings OWNER TO directus;

--
-- Name: directus_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_settings_id_seq OWNER TO directus;

--
-- Name: directus_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_settings_id_seq OWNED BY public.directus_settings.id;


--
-- Name: directus_shares; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_shares (
    id uuid NOT NULL,
    name character varying(255),
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    role uuid,
    password character varying(255),
    user_created uuid,
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    date_start timestamp with time zone,
    date_end timestamp with time zone,
    times_used integer DEFAULT 0,
    max_uses integer
);


ALTER TABLE public.directus_shares OWNER TO directus;

--
-- Name: directus_translations; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_translations (
    id uuid NOT NULL,
    language character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.directus_translations OWNER TO directus;

--
-- Name: directus_users; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_users (
    id uuid NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(128),
    password character varying(255),
    location character varying(255),
    title character varying(50),
    description text,
    tags json,
    avatar uuid,
    language character varying(255) DEFAULT NULL::character varying,
    tfa_secret character varying(255),
    status character varying(16) DEFAULT 'active'::character varying NOT NULL,
    role uuid,
    token character varying(255),
    last_access timestamp with time zone,
    last_page character varying(255),
    provider character varying(128) DEFAULT 'default'::character varying NOT NULL,
    external_identifier character varying(255),
    auth_data json,
    email_notifications boolean DEFAULT true,
    appearance character varying(255),
    theme_dark character varying(255),
    theme_light character varying(255),
    theme_light_overrides json,
    theme_dark_overrides json
);


ALTER TABLE public.directus_users OWNER TO directus;

--
-- Name: directus_versions; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_versions (
    id uuid NOT NULL,
    key character varying(64) NOT NULL,
    name character varying(255),
    collection character varying(64) NOT NULL,
    item character varying(255) NOT NULL,
    hash character varying(255),
    date_created timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    date_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_created uuid,
    user_updated uuid
);


ALTER TABLE public.directus_versions OWNER TO directus;

--
-- Name: directus_webhooks; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.directus_webhooks (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    method character varying(10) DEFAULT 'POST'::character varying NOT NULL,
    url character varying(255) NOT NULL,
    status character varying(10) DEFAULT 'active'::character varying NOT NULL,
    data boolean DEFAULT true NOT NULL,
    actions character varying(100) NOT NULL,
    collections character varying(255) NOT NULL,
    headers json,
    was_active_before_deprecation boolean DEFAULT false NOT NULL,
    migrated_flow uuid
);


ALTER TABLE public.directus_webhooks OWNER TO directus;

--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.directus_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.directus_webhooks_id_seq OWNER TO directus;

--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.directus_webhooks_id_seq OWNED BY public.directus_webhooks.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.feedback (
    id integer NOT NULL,
    date_created timestamp with time zone,
    subject character varying(255) DEFAULT NULL::character varying,
    message text,
    email character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.feedback OWNER TO directus;

--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feedback_id_seq OWNER TO directus;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: footer; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.footer (
    id integer NOT NULL,
    "showLogo" boolean DEFAULT true,
    "showSlogan" boolean DEFAULT true,
    content text,
    "showVersion" boolean
);


ALTER TABLE public.footer OWNER TO directus;

--
-- Name: footer_blocks; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.footer_blocks (
    id integer NOT NULL,
    footer_id integer,
    item character varying(255) DEFAULT NULL::character varying,
    collection character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.footer_blocks OWNER TO directus;

--
-- Name: footer_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.footer_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.footer_blocks_id_seq OWNER TO directus;

--
-- Name: footer_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.footer_blocks_id_seq OWNED BY public.footer_blocks.id;


--
-- Name: footer_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.footer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.footer_id_seq OWNER TO directus;

--
-- Name: footer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.footer_id_seq OWNED BY public.footer.id;


--
-- Name: globals; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.globals (
    id integer NOT NULL,
    "websiteName" character varying(255) DEFAULT NULL::character varying,
    "websiteSlogan" character varying(255) DEFAULT NULL::character varying,
    "logoLightMode" uuid,
    "logoDarkMode" uuid,
    "startButtonText" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.globals OWNER TO directus;

--
-- Name: globals_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.globals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.globals_id_seq OWNER TO directus;

--
-- Name: globals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.globals_id_seq OWNED BY public.globals.id;


--
-- Name: header; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.header (
    id integer NOT NULL,
    "lightSwitch" boolean DEFAULT true
);


ALTER TABLE public.header OWNER TO directus;

--
-- Name: header_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.header_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.header_id_seq OWNER TO directus;

--
-- Name: header_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.header_id_seq OWNED BY public.header.id;


--
-- Name: image; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.image (
    id integer NOT NULL,
    image integer
);


ALTER TABLE public.image OWNER TO directus;

--
-- Name: imageBlock; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."imageBlock" (
    id integer NOT NULL,
    image uuid,
    caption character varying(255) DEFAULT NULL::character varying,
    alt character varying(255) DEFAULT NULL::character varying,
    "internalTitle" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."imageBlock" OWNER TO directus;

--
-- Name: imageBlock_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."imageBlock_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."imageBlock_id_seq" OWNER TO directus;

--
-- Name: imageBlock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."imageBlock_id_seq" OWNED BY public."imageBlock".id;


--
-- Name: image_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_id_seq OWNER TO directus;

--
-- Name: image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.image_id_seq OWNED BY public.image.id;


--
-- Name: link; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.link (
    id integer NOT NULL,
    link integer
);


ALTER TABLE public.link OWNER TO directus;

--
-- Name: link_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.link_id_seq OWNER TO directus;

--
-- Name: link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.link_id_seq OWNED BY public.link.id;


--
-- Name: page_editor_nodes; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.page_editor_nodes (
    id uuid NOT NULL,
    item character varying(255) DEFAULT NULL::character varying,
    collection character varying(255) DEFAULT NULL::character varying,
    pages_id integer
);


ALTER TABLE public.page_editor_nodes OWNER TO directus;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    slug character varying(255) DEFAULT NULL::character varying NOT NULL,
    title character varying(255) DEFAULT NULL::character varying NOT NULL,
    icon character varying(255) DEFAULT NULL::character varying NOT NULL,
    "navigationTitle" character varying(255) DEFAULT NULL::character varying,
    "parentPage" integer,
    "manualSort" integer,
    content json,
    likes integer DEFAULT 0,
    dislikes integer DEFAULT 0,
    "titleImage" uuid,
    "subTitle" text,
    "internalTitle" character varying(255) DEFAULT NULL::character varying,
    "aiContent" text,
    "altTitleImage" character varying(255) DEFAULT NULL::character varying,
    "captionTitleImage" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.pages OWNER TO directus;

--
-- Name: pages_blocks; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.pages_blocks (
    id integer NOT NULL,
    pages_id integer,
    item character varying(255) DEFAULT NULL::character varying,
    collection character varying(255) DEFAULT NULL::character varying,
    "manualSort" integer
);


ALTER TABLE public.pages_blocks OWNER TO directus;

--
-- Name: pages_blocks_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.pages_blocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_blocks_id_seq OWNER TO directus;

--
-- Name: pages_blocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.pages_blocks_id_seq OWNED BY public.pages_blocks.id;


--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_id_seq OWNER TO directus;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: popup; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public.popup (
    id integer NOT NULL,
    popup integer
);


ALTER TABLE public.popup OWNER TO directus;

--
-- Name: popup_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public.popup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.popup_id_seq OWNER TO directus;

--
-- Name: popup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public.popup_id_seq OWNED BY public.popup.id;


--
-- Name: smallText; Type: TABLE; Schema: public; Owner: directus
--

CREATE TABLE public."smallText" (
    id integer NOT NULL,
    "smallText" integer
);


ALTER TABLE public."smallText" OWNER TO directus;

--
-- Name: smallText_id_seq; Type: SEQUENCE; Schema: public; Owner: directus
--

CREATE SEQUENCE public."smallText_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."smallText_id_seq" OWNER TO directus;

--
-- Name: smallText_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: directus
--

ALTER SEQUENCE public."smallText_id_seq" OWNED BY public."smallText".id;


--
-- Name: accordion id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.accordion ALTER COLUMN id SET DEFAULT nextval('public.accordion_id_seq'::regclass);


--
-- Name: blockAccordion id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockAccordion" ALTER COLUMN id SET DEFAULT nextval('public."blockAccordion_id_seq"'::regclass);


--
-- Name: blockAccordionItem id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockAccordionItem" ALTER COLUMN id SET DEFAULT nextval('public."blockAccordionItem_id_seq"'::regclass);


--
-- Name: blockCard id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCard" ALTER COLUMN id SET DEFAULT nextval('public."blockCard_id_seq"'::regclass);


--
-- Name: blockCardGroup id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup" ALTER COLUMN id SET DEFAULT nextval('public."blockCardGroup_id_seq"'::regclass);


--
-- Name: blockCardGroup_blockCard id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup_blockCard" ALTER COLUMN id SET DEFAULT nextval('public."blockCardGroup_blockCard_id_seq"'::regclass);


--
-- Name: blockLink id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink" ALTER COLUMN id SET DEFAULT nextval('public."blockLink_id_seq"'::regclass);


--
-- Name: blockLinkGroup id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLinkGroup" ALTER COLUMN id SET DEFAULT nextval('public."blockLinkGroup_id_seq"'::regclass);


--
-- Name: blockPopup id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockPopup" ALTER COLUMN id SET DEFAULT nextval('public."blockPopup_id_seq"'::regclass);


--
-- Name: blockSmallText id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockSmallText" ALTER COLUMN id SET DEFAULT nextval('public."blockSmallText_id_seq"'::regclass);


--
-- Name: cardGroup id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."cardGroup" ALTER COLUMN id SET DEFAULT nextval('public."cardGroup_id_seq"'::regclass);


--
-- Name: directus_activity id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_activity ALTER COLUMN id SET DEFAULT nextval('public.directus_activity_id_seq'::regclass);


--
-- Name: directus_fields id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_fields ALTER COLUMN id SET DEFAULT nextval('public.directus_fields_id_seq'::regclass);


--
-- Name: directus_notifications id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications ALTER COLUMN id SET DEFAULT nextval('public.directus_notifications_id_seq'::regclass);


--
-- Name: directus_permissions id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions ALTER COLUMN id SET DEFAULT nextval('public.directus_permissions_id_seq'::regclass);


--
-- Name: directus_presets id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets ALTER COLUMN id SET DEFAULT nextval('public.directus_presets_id_seq'::regclass);


--
-- Name: directus_relations id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_relations ALTER COLUMN id SET DEFAULT nextval('public.directus_relations_id_seq'::regclass);


--
-- Name: directus_revisions id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions ALTER COLUMN id SET DEFAULT nextval('public.directus_revisions_id_seq'::regclass);


--
-- Name: directus_settings id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings ALTER COLUMN id SET DEFAULT nextval('public.directus_settings_id_seq'::regclass);


--
-- Name: directus_webhooks id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_webhooks ALTER COLUMN id SET DEFAULT nextval('public.directus_webhooks_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: footer id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.footer ALTER COLUMN id SET DEFAULT nextval('public.footer_id_seq'::regclass);


--
-- Name: footer_blocks id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.footer_blocks ALTER COLUMN id SET DEFAULT nextval('public.footer_blocks_id_seq'::regclass);


--
-- Name: globals id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.globals ALTER COLUMN id SET DEFAULT nextval('public.globals_id_seq'::regclass);


--
-- Name: header id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.header ALTER COLUMN id SET DEFAULT nextval('public.header_id_seq'::regclass);


--
-- Name: image id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.image ALTER COLUMN id SET DEFAULT nextval('public.image_id_seq'::regclass);


--
-- Name: imageBlock id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."imageBlock" ALTER COLUMN id SET DEFAULT nextval('public."imageBlock_id_seq"'::regclass);


--
-- Name: link id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.link ALTER COLUMN id SET DEFAULT nextval('public.link_id_seq'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: pages_blocks id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages_blocks ALTER COLUMN id SET DEFAULT nextval('public.pages_blocks_id_seq'::regclass);


--
-- Name: popup id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.popup ALTER COLUMN id SET DEFAULT nextval('public.popup_id_seq'::regclass);


--
-- Name: smallText id; Type: DEFAULT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."smallText" ALTER COLUMN id SET DEFAULT nextval('public."smallText_id_seq"'::regclass);


--
-- Data for Name: accordion; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.accordion (id, accordion) FROM stdin;
\.
COPY public.accordion (id, accordion) FROM '$$PATH$$/3643.dat';

--
-- Data for Name: blockAccordion; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockAccordion" (id, "manualSort", "Internal_Title") FROM stdin;
\.
COPY public."blockAccordion" (id, "manualSort", "Internal_Title") FROM '$$PATH$$/3623.dat';

--
-- Data for Name: blockAccordionItem; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockAccordionItem" (id, accordion, "manualSort", icon, title, content, "Internal_Titel") FROM stdin;
\.
COPY public."blockAccordionItem" (id, accordion, "manualSort", icon, title, content, "Internal_Titel") FROM '$$PATH$$/3625.dat';

--
-- Data for Name: blockCard; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockCard" (id, title, page, "manualSort", image, "Internal_Titel", content) FROM stdin;
\.
COPY public."blockCard" (id, title, page, "manualSort", image, "Internal_Titel", content) FROM '$$PATH$$/3629.dat';

--
-- Data for Name: blockCardGroup; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockCardGroup" (id, title, "manualSort", "internalTitle") FROM stdin;
\.
COPY public."blockCardGroup" (id, title, "manualSort", "internalTitle") FROM '$$PATH$$/3627.dat';

--
-- Data for Name: blockCardGroup_blockCard; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockCardGroup_blockCard" (id, "blockCardGroup_id", card, "manualSort") FROM stdin;
\.
COPY public."blockCardGroup_blockCard" (id, "blockCardGroup_id", card, "manualSort") FROM '$$PATH$$/3631.dat';

--
-- Data for Name: blockLink; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockLink" (id, name, url, "manualSort", "linkGroupId", page, "footerId", "contactForm", "Internal_Titel") FROM stdin;
\.
COPY public."blockLink" (id, name, url, "manualSort", "linkGroupId", page, "footerId", "contactForm", "Internal_Titel") FROM '$$PATH$$/3633.dat';

--
-- Data for Name: blockLinkGroup; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockLinkGroup" (id, title, "manualSort") FROM stdin;
\.
COPY public."blockLinkGroup" (id, title, "manualSort") FROM '$$PATH$$/3635.dat';

--
-- Data for Name: blockPopup; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockPopup" (id, title, icon, content) FROM stdin;
\.
COPY public."blockPopup" (id, title, icon, content) FROM '$$PATH$$/3637.dat';

--
-- Data for Name: blockSmallText; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."blockSmallText" (id, content, "Internal_Title") FROM stdin;
\.
COPY public."blockSmallText" (id, content, "Internal_Title") FROM '$$PATH$$/3639.dat';

--
-- Data for Name: cardGroup; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."cardGroup" (id, "cardGroup") FROM stdin;
\.
COPY public."cardGroup" (id, "cardGroup") FROM '$$PATH$$/3645.dat';

--
-- Data for Name: directus_activity; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_activity (id, action, "user", "timestamp", ip, user_agent, collection, item, comment, origin) FROM stdin;
\.
COPY public.directus_activity (id, action, "user", "timestamp", ip, user_agent, collection, item, comment, origin) FROM '$$PATH$$/3595.dat';

--
-- Data for Name: directus_collections; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_collections (collection, icon, note, display_template, hidden, singleton, translations, archive_field, archive_app_filter, archive_value, unarchive_value, sort_field, accountability, color, item_duplication_fields, sort, "group", collapse, preview_url, versioning) FROM stdin;
\.
COPY public.directus_collections (collection, icon, note, display_template, hidden, singleton, translations, archive_field, archive_app_filter, archive_value, unarchive_value, sort_field, accountability, color, item_duplication_fields, sort, "group", collapse, preview_url, versioning) FROM '$$PATH$$/3589.dat';

--
-- Data for Name: directus_dashboards; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_dashboards (id, name, icon, note, date_created, user_created, color) FROM stdin;
\.
COPY public.directus_dashboards (id, name, icon, note, date_created, user_created, color) FROM '$$PATH$$/3612.dat';

--
-- Data for Name: directus_extensions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_extensions (enabled, id, folder, source, bundle) FROM stdin;
\.
COPY public.directus_extensions (enabled, id, folder, source, bundle) FROM '$$PATH$$/3621.dat';

--
-- Data for Name: directus_fields; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_fields (id, collection, field, special, interface, options, display, display_options, readonly, hidden, sort, width, translations, note, conditions, required, "group", validation, validation_message) FROM stdin;
\.
COPY public.directus_fields (id, collection, field, special, interface, options, display, display_options, readonly, hidden, sort, width, translations, note, conditions, required, "group", validation, validation_message) FROM '$$PATH$$/3593.dat';

--
-- Data for Name: directus_files; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_files (id, storage, filename_disk, filename_download, title, type, folder, uploaded_by, uploaded_on, modified_by, modified_on, charset, filesize, width, height, duration, embed, description, location, tags, metadata, focal_point_x, focal_point_y) FROM stdin;
\.
COPY public.directus_files (id, storage, filename_disk, filename_download, title, type, folder, uploaded_by, uploaded_on, modified_by, modified_on, charset, filesize, width, height, duration, embed, description, location, tags, metadata, focal_point_x, focal_point_y) FROM '$$PATH$$/3597.dat';

--
-- Data for Name: directus_flows; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_flows (id, name, icon, color, description, status, trigger, accountability, options, operation, date_created, user_created) FROM stdin;
\.
COPY public.directus_flows (id, name, icon, color, description, status, trigger, accountability, options, operation, date_created, user_created) FROM '$$PATH$$/3617.dat';

--
-- Data for Name: directus_folders; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_folders (id, name, parent) FROM stdin;
\.
COPY public.directus_folders (id, name, parent) FROM '$$PATH$$/3596.dat';

--
-- Data for Name: directus_migrations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_migrations (version, name, "timestamp") FROM stdin;
\.
COPY public.directus_migrations (version, name, "timestamp") FROM '$$PATH$$/3611.dat';

--
-- Data for Name: directus_notifications; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_notifications (id, "timestamp", status, recipient, sender, subject, message, collection, item) FROM stdin;
\.
COPY public.directus_notifications (id, "timestamp", status, recipient, sender, subject, message, collection, item) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: directus_operations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_operations (id, name, key, type, position_x, position_y, options, resolve, reject, flow, date_created, user_created) FROM stdin;
\.
COPY public.directus_operations (id, name, key, type, position_x, position_y, options, resolve, reject, flow, date_created, user_created) FROM '$$PATH$$/3618.dat';

--
-- Data for Name: directus_panels; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_panels (id, dashboard, name, icon, color, show_header, note, type, position_x, position_y, width, height, options, date_created, user_created) FROM stdin;
\.
COPY public.directus_panels (id, dashboard, name, icon, color, show_header, note, type, position_x, position_y, width, height, options, date_created, user_created) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: directus_permissions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_permissions (id, role, collection, action, permissions, validation, presets, fields) FROM stdin;
\.
COPY public.directus_permissions (id, role, collection, action, permissions, validation, presets, fields) FROM '$$PATH$$/3599.dat';

--
-- Data for Name: directus_presets; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_presets (id, bookmark, "user", role, collection, search, layout, layout_query, layout_options, refresh_interval, filter, icon, color) FROM stdin;
\.
COPY public.directus_presets (id, bookmark, "user", role, collection, search, layout, layout_query, layout_options, refresh_interval, filter, icon, color) FROM '$$PATH$$/3601.dat';

--
-- Data for Name: directus_relations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_relations (id, many_collection, many_field, one_collection, one_field, one_collection_field, one_allowed_collections, junction_field, sort_field, one_deselect_action) FROM stdin;
\.
COPY public.directus_relations (id, many_collection, many_field, one_collection, one_field, one_collection_field, one_allowed_collections, junction_field, sort_field, one_deselect_action) FROM '$$PATH$$/3603.dat';

--
-- Data for Name: directus_revisions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_revisions (id, activity, collection, item, data, delta, parent, version) FROM stdin;
\.
COPY public.directus_revisions (id, activity, collection, item, data, delta, parent, version) FROM '$$PATH$$/3605.dat';

--
-- Data for Name: directus_roles; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_roles (id, name, icon, description, ip_access, enforce_tfa, admin_access, app_access) FROM stdin;
\.
COPY public.directus_roles (id, name, icon, description, ip_access, enforce_tfa, admin_access, app_access) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: directus_sessions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_sessions (token, "user", expires, ip, user_agent, share, origin) FROM stdin;
\.
COPY public.directus_sessions (token, "user", expires, ip, user_agent, share, origin) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: directus_settings; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_settings (id, project_name, project_url, project_color, project_logo, public_foreground, public_background, public_note, auth_login_attempts, auth_password_policy, storage_asset_transform, storage_asset_presets, custom_css, storage_default_folder, basemaps, mapbox_key, module_bar, project_descriptor, default_language, custom_aspect_ratios, public_favicon, default_appearance, default_theme_light, theme_light_overrides, default_theme_dark, theme_dark_overrides, report_error_url, report_bug_url, report_feature_url) FROM stdin;
\.
COPY public.directus_settings (id, project_name, project_url, project_color, project_logo, public_foreground, public_background, public_note, auth_login_attempts, auth_password_policy, storage_asset_transform, storage_asset_presets, custom_css, storage_default_folder, basemaps, mapbox_key, module_bar, project_descriptor, default_language, custom_aspect_ratios, public_favicon, default_appearance, default_theme_light, theme_light_overrides, default_theme_dark, theme_dark_overrides, report_error_url, report_bug_url, report_feature_url) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: directus_shares; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_shares (id, name, collection, item, role, password, user_created, date_created, date_start, date_end, times_used, max_uses) FROM stdin;
\.
COPY public.directus_shares (id, name, collection, item, role, password, user_created, date_created, date_start, date_end, times_used, max_uses) FROM '$$PATH$$/3616.dat';

--
-- Data for Name: directus_translations; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_translations (id, language, key, value) FROM stdin;
\.
COPY public.directus_translations (id, language, key, value) FROM '$$PATH$$/3619.dat';

--
-- Data for Name: directus_users; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_users (id, first_name, last_name, email, password, location, title, description, tags, avatar, language, tfa_secret, status, role, token, last_access, last_page, provider, external_identifier, auth_data, email_notifications, appearance, theme_dark, theme_light, theme_light_overrides, theme_dark_overrides) FROM stdin;
\.
COPY public.directus_users (id, first_name, last_name, email, password, location, title, description, tags, avatar, language, tfa_secret, status, role, token, last_access, last_page, provider, external_identifier, auth_data, email_notifications, appearance, theme_dark, theme_light, theme_light_overrides, theme_dark_overrides) FROM '$$PATH$$/3591.dat';

--
-- Data for Name: directus_versions; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_versions (id, key, name, collection, item, hash, date_created, date_updated, user_created, user_updated) FROM stdin;
\.
COPY public.directus_versions (id, key, name, collection, item, hash, date_created, date_updated, user_created, user_updated) FROM '$$PATH$$/3620.dat';

--
-- Data for Name: directus_webhooks; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.directus_webhooks (id, name, method, url, status, data, actions, collections, headers, was_active_before_deprecation, migrated_flow) FROM stdin;
\.
COPY public.directus_webhooks (id, name, method, url, status, data, actions, collections, headers, was_active_before_deprecation, migrated_flow) FROM '$$PATH$$/3610.dat';

--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.feedback (id, date_created, subject, message, email) FROM stdin;
\.
COPY public.feedback (id, date_created, subject, message, email) FROM '$$PATH$$/3655.dat';

--
-- Data for Name: footer; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.footer (id, "showLogo", "showSlogan", content, "showVersion") FROM stdin;
\.
COPY public.footer (id, "showLogo", "showSlogan", content, "showVersion") FROM '$$PATH$$/3657.dat';

--
-- Data for Name: footer_blocks; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.footer_blocks (id, footer_id, item, collection) FROM stdin;
\.
COPY public.footer_blocks (id, footer_id, item, collection) FROM '$$PATH$$/3659.dat';

--
-- Data for Name: globals; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.globals (id, "websiteName", "websiteSlogan", "logoLightMode", "logoDarkMode", "startButtonText") FROM stdin;
\.
COPY public.globals (id, "websiteName", "websiteSlogan", "logoLightMode", "logoDarkMode", "startButtonText") FROM '$$PATH$$/3661.dat';

--
-- Data for Name: header; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.header (id, "lightSwitch") FROM stdin;
\.
COPY public.header (id, "lightSwitch") FROM '$$PATH$$/3663.dat';

--
-- Data for Name: image; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.image (id, image) FROM stdin;
\.
COPY public.image (id, image) FROM '$$PATH$$/3647.dat';

--
-- Data for Name: imageBlock; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."imageBlock" (id, image, caption, alt, "internalTitle") FROM stdin;
\.
COPY public."imageBlock" (id, image, caption, alt, "internalTitle") FROM '$$PATH$$/3641.dat';

--
-- Data for Name: link; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.link (id, link) FROM stdin;
\.
COPY public.link (id, link) FROM '$$PATH$$/3649.dat';

--
-- Data for Name: page_editor_nodes; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.page_editor_nodes (id, item, collection, pages_id) FROM stdin;
\.
COPY public.page_editor_nodes (id, item, collection, pages_id) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.pages (id, slug, title, icon, "navigationTitle", "parentPage", "manualSort", content, likes, dislikes, "titleImage", "subTitle", "internalTitle", "aiContent", "altTitleImage", "captionTitleImage") FROM stdin;
\.
COPY public.pages (id, slug, title, icon, "navigationTitle", "parentPage", "manualSort", content, likes, dislikes, "titleImage", "subTitle", "internalTitle", "aiContent", "altTitleImage", "captionTitleImage") FROM '$$PATH$$/3665.dat';

--
-- Data for Name: pages_blocks; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.pages_blocks (id, pages_id, item, collection, "manualSort") FROM stdin;
\.
COPY public.pages_blocks (id, pages_id, item, collection, "manualSort") FROM '$$PATH$$/3668.dat';

--
-- Data for Name: popup; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public.popup (id, popup) FROM stdin;
\.
COPY public.popup (id, popup) FROM '$$PATH$$/3651.dat';

--
-- Data for Name: smallText; Type: TABLE DATA; Schema: public; Owner: directus
--

COPY public."smallText" (id, "smallText") FROM stdin;
\.
COPY public."smallText" (id, "smallText") FROM '$$PATH$$/3653.dat';

--
-- Name: accordion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.accordion_id_seq', 1, false);


--
-- Name: blockAccordionItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockAccordionItem_id_seq"', 1, false);


--
-- Name: blockAccordion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockAccordion_id_seq"', 1, false);


--
-- Name: blockCardGroup_blockCard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockCardGroup_blockCard_id_seq"', 1, false);


--
-- Name: blockCardGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockCardGroup_id_seq"', 1, false);


--
-- Name: blockCard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockCard_id_seq"', 1, false);


--
-- Name: blockLinkGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockLinkGroup_id_seq"', 1, false);


--
-- Name: blockLink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockLink_id_seq"', 1, false);


--
-- Name: blockPopup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockPopup_id_seq"', 1, false);


--
-- Name: blockSmallText_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."blockSmallText_id_seq"', 1, false);


--
-- Name: cardGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."cardGroup_id_seq"', 1, false);


--
-- Name: directus_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_activity_id_seq', 1, false);


--
-- Name: directus_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_fields_id_seq', 115, true);


--
-- Name: directus_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_notifications_id_seq', 1, false);


--
-- Name: directus_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_permissions_id_seq', 1, false);


--
-- Name: directus_presets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_presets_id_seq', 1, false);


--
-- Name: directus_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_relations_id_seq', 25, true);


--
-- Name: directus_revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_revisions_id_seq', 1, false);


--
-- Name: directus_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_settings_id_seq', 1, false);


--
-- Name: directus_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.directus_webhooks_id_seq', 1, false);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: footer_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.footer_blocks_id_seq', 1, false);


--
-- Name: footer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.footer_id_seq', 1, false);


--
-- Name: globals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.globals_id_seq', 1, false);


--
-- Name: header_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.header_id_seq', 1, false);


--
-- Name: imageBlock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."imageBlock_id_seq"', 1, false);


--
-- Name: image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.image_id_seq', 1, false);


--
-- Name: link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.link_id_seq', 1, false);


--
-- Name: pages_blocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.pages_blocks_id_seq', 1, false);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.pages_id_seq', 1, false);


--
-- Name: popup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public.popup_id_seq', 1, false);


--
-- Name: smallText_id_seq; Type: SEQUENCE SET; Schema: public; Owner: directus
--

SELECT pg_catalog.setval('public."smallText_id_seq"', 1, false);


--
-- Name: accordion accordion_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.accordion
    ADD CONSTRAINT accordion_pkey PRIMARY KEY (id);


--
-- Name: blockAccordionItem blockAccordionItem_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockAccordionItem"
    ADD CONSTRAINT "blockAccordionItem_pkey" PRIMARY KEY (id);


--
-- Name: blockAccordion blockAccordion_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockAccordion"
    ADD CONSTRAINT "blockAccordion_pkey" PRIMARY KEY (id);


--
-- Name: blockCardGroup_blockCard blockCardGroup_blockCard_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup_blockCard"
    ADD CONSTRAINT "blockCardGroup_blockCard_pkey" PRIMARY KEY (id);


--
-- Name: blockCardGroup blockCardGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup"
    ADD CONSTRAINT "blockCardGroup_pkey" PRIMARY KEY (id);


--
-- Name: blockCard blockCard_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCard"
    ADD CONSTRAINT "blockCard_pkey" PRIMARY KEY (id);


--
-- Name: blockLinkGroup blockLinkGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLinkGroup"
    ADD CONSTRAINT "blockLinkGroup_pkey" PRIMARY KEY (id);


--
-- Name: blockLink blockLink_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink"
    ADD CONSTRAINT "blockLink_pkey" PRIMARY KEY (id);


--
-- Name: blockPopup blockPopup_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockPopup"
    ADD CONSTRAINT "blockPopup_pkey" PRIMARY KEY (id);


--
-- Name: blockSmallText blockSmallText_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockSmallText"
    ADD CONSTRAINT "blockSmallText_pkey" PRIMARY KEY (id);


--
-- Name: blockLink blocklink_page_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink"
    ADD CONSTRAINT blocklink_page_unique UNIQUE (page);


--
-- Name: cardGroup cardGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."cardGroup"
    ADD CONSTRAINT "cardGroup_pkey" PRIMARY KEY (id);


--
-- Name: directus_activity directus_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_activity
    ADD CONSTRAINT directus_activity_pkey PRIMARY KEY (id);


--
-- Name: directus_collections directus_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_pkey PRIMARY KEY (collection);


--
-- Name: directus_dashboards directus_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_pkey PRIMARY KEY (id);


--
-- Name: directus_extensions directus_extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_extensions
    ADD CONSTRAINT directus_extensions_pkey PRIMARY KEY (id);


--
-- Name: directus_fields directus_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_fields
    ADD CONSTRAINT directus_fields_pkey PRIMARY KEY (id);


--
-- Name: directus_files directus_files_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_pkey PRIMARY KEY (id);


--
-- Name: directus_flows directus_flows_operation_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_operation_unique UNIQUE (operation);


--
-- Name: directus_flows directus_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_pkey PRIMARY KEY (id);


--
-- Name: directus_folders directus_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_pkey PRIMARY KEY (id);


--
-- Name: directus_migrations directus_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_migrations
    ADD CONSTRAINT directus_migrations_pkey PRIMARY KEY (version);


--
-- Name: directus_notifications directus_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_pkey PRIMARY KEY (id);


--
-- Name: directus_operations directus_operations_reject_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_unique UNIQUE (reject);


--
-- Name: directus_operations directus_operations_resolve_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_unique UNIQUE (resolve);


--
-- Name: directus_panels directus_panels_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_pkey PRIMARY KEY (id);


--
-- Name: directus_permissions directus_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_pkey PRIMARY KEY (id);


--
-- Name: directus_presets directus_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_pkey PRIMARY KEY (id);


--
-- Name: directus_relations directus_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_relations
    ADD CONSTRAINT directus_relations_pkey PRIMARY KEY (id);


--
-- Name: directus_revisions directus_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_pkey PRIMARY KEY (id);


--
-- Name: directus_roles directus_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_roles
    ADD CONSTRAINT directus_roles_pkey PRIMARY KEY (id);


--
-- Name: directus_sessions directus_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_pkey PRIMARY KEY (token);


--
-- Name: directus_settings directus_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_pkey PRIMARY KEY (id);


--
-- Name: directus_shares directus_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_pkey PRIMARY KEY (id);


--
-- Name: directus_translations directus_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_translations
    ADD CONSTRAINT directus_translations_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_email_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_email_unique UNIQUE (email);


--
-- Name: directus_users directus_users_external_identifier_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_external_identifier_unique UNIQUE (external_identifier);


--
-- Name: directus_users directus_users_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_pkey PRIMARY KEY (id);


--
-- Name: directus_users directus_users_token_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_token_unique UNIQUE (token);


--
-- Name: directus_versions directus_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_versions
    ADD CONSTRAINT directus_versions_pkey PRIMARY KEY (id);


--
-- Name: directus_webhooks directus_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_webhooks
    ADD CONSTRAINT directus_webhooks_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: footer_blocks footer_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.footer_blocks
    ADD CONSTRAINT footer_blocks_pkey PRIMARY KEY (id);


--
-- Name: footer footer_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.footer
    ADD CONSTRAINT footer_pkey PRIMARY KEY (id);


--
-- Name: globals globals_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.globals
    ADD CONSTRAINT globals_pkey PRIMARY KEY (id);


--
-- Name: header header_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.header
    ADD CONSTRAINT header_pkey PRIMARY KEY (id);


--
-- Name: imageBlock imageBlock_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."imageBlock"
    ADD CONSTRAINT "imageBlock_pkey" PRIMARY KEY (id);


--
-- Name: image image_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_pkey PRIMARY KEY (id);


--
-- Name: link link_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.link
    ADD CONSTRAINT link_pkey PRIMARY KEY (id);


--
-- Name: page_editor_nodes page_editor_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.page_editor_nodes
    ADD CONSTRAINT page_editor_nodes_pkey PRIMARY KEY (id);


--
-- Name: pages_blocks pages_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages_blocks
    ADD CONSTRAINT pages_blocks_pkey PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: pages pages_slug_unique; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_slug_unique UNIQUE (slug);


--
-- Name: popup popup_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.popup
    ADD CONSTRAINT popup_pkey PRIMARY KEY (id);


--
-- Name: smallText smallText_pkey; Type: CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."smallText"
    ADD CONSTRAINT "smallText_pkey" PRIMARY KEY (id);


--
-- Name: accordion accordion_accordion_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.accordion
    ADD CONSTRAINT accordion_accordion_foreign FOREIGN KEY (accordion) REFERENCES public."blockAccordion"(id) ON DELETE SET NULL;


--
-- Name: blockAccordionItem blockaccordionitem_accordion_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockAccordionItem"
    ADD CONSTRAINT blockaccordionitem_accordion_foreign FOREIGN KEY (accordion) REFERENCES public."blockAccordion"(id) ON DELETE SET NULL;


--
-- Name: blockCard blockcard_image_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCard"
    ADD CONSTRAINT blockcard_image_foreign FOREIGN KEY (image) REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- Name: blockCard blockcard_page_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCard"
    ADD CONSTRAINT blockcard_page_foreign FOREIGN KEY (page) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: blockCardGroup_blockCard blockcardgroup_blockcard_blockcardgroup_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup_blockCard"
    ADD CONSTRAINT blockcardgroup_blockcard_blockcardgroup_id_foreign FOREIGN KEY ("blockCardGroup_id") REFERENCES public."blockCardGroup"(id) ON DELETE SET NULL;


--
-- Name: blockCardGroup_blockCard blockcardgroup_blockcard_card_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockCardGroup_blockCard"
    ADD CONSTRAINT blockcardgroup_blockcard_card_foreign FOREIGN KEY (card) REFERENCES public."blockCard"(id) ON DELETE SET NULL;


--
-- Name: blockLink blocklink_footerid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink"
    ADD CONSTRAINT blocklink_footerid_foreign FOREIGN KEY ("footerId") REFERENCES public.footer(id) ON DELETE SET NULL;


--
-- Name: blockLink blocklink_linkgroupid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink"
    ADD CONSTRAINT blocklink_linkgroupid_foreign FOREIGN KEY ("linkGroupId") REFERENCES public."blockLinkGroup"(id) ON DELETE SET NULL;


--
-- Name: blockLink blocklink_page_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."blockLink"
    ADD CONSTRAINT blocklink_page_foreign FOREIGN KEY (page) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: cardGroup cardgroup_cardgroup_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."cardGroup"
    ADD CONSTRAINT cardgroup_cardgroup_foreign FOREIGN KEY ("cardGroup") REFERENCES public."blockCardGroup"(id) ON DELETE SET NULL;


--
-- Name: directus_collections directus_collections_group_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_collections
    ADD CONSTRAINT directus_collections_group_foreign FOREIGN KEY ("group") REFERENCES public.directus_collections(collection);


--
-- Name: directus_dashboards directus_dashboards_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_dashboards
    ADD CONSTRAINT directus_dashboards_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_folder_foreign FOREIGN KEY (folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_files directus_files_modified_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_modified_by_foreign FOREIGN KEY (modified_by) REFERENCES public.directus_users(id);


--
-- Name: directus_files directus_files_uploaded_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_files
    ADD CONSTRAINT directus_files_uploaded_by_foreign FOREIGN KEY (uploaded_by) REFERENCES public.directus_users(id);


--
-- Name: directus_flows directus_flows_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_flows
    ADD CONSTRAINT directus_flows_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_folders directus_folders_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_folders
    ADD CONSTRAINT directus_folders_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_folders(id);


--
-- Name: directus_notifications directus_notifications_recipient_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_recipient_foreign FOREIGN KEY (recipient) REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_notifications directus_notifications_sender_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_notifications
    ADD CONSTRAINT directus_notifications_sender_foreign FOREIGN KEY (sender) REFERENCES public.directus_users(id);


--
-- Name: directus_operations directus_operations_flow_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_flow_foreign FOREIGN KEY (flow) REFERENCES public.directus_flows(id) ON DELETE CASCADE;


--
-- Name: directus_operations directus_operations_reject_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_reject_foreign FOREIGN KEY (reject) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_resolve_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_resolve_foreign FOREIGN KEY (resolve) REFERENCES public.directus_operations(id);


--
-- Name: directus_operations directus_operations_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_operations
    ADD CONSTRAINT directus_operations_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_panels directus_panels_dashboard_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_dashboard_foreign FOREIGN KEY (dashboard) REFERENCES public.directus_dashboards(id) ON DELETE CASCADE;


--
-- Name: directus_panels directus_panels_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_panels
    ADD CONSTRAINT directus_panels_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_permissions directus_permissions_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_permissions
    ADD CONSTRAINT directus_permissions_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_presets directus_presets_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_presets
    ADD CONSTRAINT directus_presets_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_activity_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_activity_foreign FOREIGN KEY (activity) REFERENCES public.directus_activity(id) ON DELETE CASCADE;


--
-- Name: directus_revisions directus_revisions_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_parent_foreign FOREIGN KEY (parent) REFERENCES public.directus_revisions(id);


--
-- Name: directus_revisions directus_revisions_version_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_revisions
    ADD CONSTRAINT directus_revisions_version_foreign FOREIGN KEY (version) REFERENCES public.directus_versions(id) ON DELETE CASCADE;


--
-- Name: directus_sessions directus_sessions_share_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_share_foreign FOREIGN KEY (share) REFERENCES public.directus_shares(id) ON DELETE CASCADE;


--
-- Name: directus_sessions directus_sessions_user_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_sessions
    ADD CONSTRAINT directus_sessions_user_foreign FOREIGN KEY ("user") REFERENCES public.directus_users(id) ON DELETE CASCADE;


--
-- Name: directus_settings directus_settings_project_logo_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_project_logo_foreign FOREIGN KEY (project_logo) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_background_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_background_foreign FOREIGN KEY (public_background) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_favicon_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_favicon_foreign FOREIGN KEY (public_favicon) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_public_foreground_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_public_foreground_foreign FOREIGN KEY (public_foreground) REFERENCES public.directus_files(id);


--
-- Name: directus_settings directus_settings_storage_default_folder_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_settings
    ADD CONSTRAINT directus_settings_storage_default_folder_foreign FOREIGN KEY (storage_default_folder) REFERENCES public.directus_folders(id) ON DELETE SET NULL;


--
-- Name: directus_shares directus_shares_collection_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_collection_foreign FOREIGN KEY (collection) REFERENCES public.directus_collections(collection) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE CASCADE;


--
-- Name: directus_shares directus_shares_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_shares
    ADD CONSTRAINT directus_shares_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_users directus_users_role_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_users
    ADD CONSTRAINT directus_users_role_foreign FOREIGN KEY (role) REFERENCES public.directus_roles(id) ON DELETE SET NULL;


--
-- Name: directus_versions directus_versions_collection_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_versions
    ADD CONSTRAINT directus_versions_collection_foreign FOREIGN KEY (collection) REFERENCES public.directus_collections(collection) ON DELETE CASCADE;


--
-- Name: directus_versions directus_versions_user_created_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_versions
    ADD CONSTRAINT directus_versions_user_created_foreign FOREIGN KEY (user_created) REFERENCES public.directus_users(id) ON DELETE SET NULL;


--
-- Name: directus_versions directus_versions_user_updated_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_versions
    ADD CONSTRAINT directus_versions_user_updated_foreign FOREIGN KEY (user_updated) REFERENCES public.directus_users(id);


--
-- Name: directus_webhooks directus_webhooks_migrated_flow_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.directus_webhooks
    ADD CONSTRAINT directus_webhooks_migrated_flow_foreign FOREIGN KEY (migrated_flow) REFERENCES public.directus_flows(id) ON DELETE SET NULL;


--
-- Name: footer_blocks footer_blocks_footer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.footer_blocks
    ADD CONSTRAINT footer_blocks_footer_id_foreign FOREIGN KEY (footer_id) REFERENCES public.footer(id) ON DELETE SET NULL;


--
-- Name: globals globals_logodarkmode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.globals
    ADD CONSTRAINT globals_logodarkmode_foreign FOREIGN KEY ("logoDarkMode") REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- Name: globals globals_logolightmode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.globals
    ADD CONSTRAINT globals_logolightmode_foreign FOREIGN KEY ("logoLightMode") REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- Name: image image_image_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.image
    ADD CONSTRAINT image_image_foreign FOREIGN KEY (image) REFERENCES public."imageBlock"(id) ON DELETE SET NULL;


--
-- Name: imageBlock imageblock_image_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."imageBlock"
    ADD CONSTRAINT imageblock_image_foreign FOREIGN KEY (image) REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- Name: link link_link_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.link
    ADD CONSTRAINT link_link_foreign FOREIGN KEY (link) REFERENCES public."blockLink"(id) ON DELETE SET NULL;


--
-- Name: page_editor_nodes page_editor_nodes_pages_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.page_editor_nodes
    ADD CONSTRAINT page_editor_nodes_pages_id_foreign FOREIGN KEY (pages_id) REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pages_blocks pages_blocks_pages_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages_blocks
    ADD CONSTRAINT pages_blocks_pages_id_foreign FOREIGN KEY (pages_id) REFERENCES public.pages(id) ON DELETE SET NULL;


--
-- Name: pages pages_parentpage_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_parentpage_foreign FOREIGN KEY ("parentPage") REFERENCES public.pages(id);


--
-- Name: pages pages_titleimage_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_titleimage_foreign FOREIGN KEY ("titleImage") REFERENCES public.directus_files(id) ON DELETE SET NULL;


--
-- Name: popup popup_popup_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public.popup
    ADD CONSTRAINT popup_popup_foreign FOREIGN KEY (popup) REFERENCES public."blockPopup"(id) ON DELETE SET NULL;


--
-- Name: smallText smalltext_smalltext_foreign; Type: FK CONSTRAINT; Schema: public; Owner: directus
--

ALTER TABLE ONLY public."smallText"
    ADD CONSTRAINT smalltext_smalltext_foreign FOREIGN KEY ("smallText") REFERENCES public."blockSmallText"(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

